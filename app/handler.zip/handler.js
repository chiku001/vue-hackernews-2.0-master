const awsServerlessExpress = require('aws-serverless-express')
const { app } = require('./app')
//const app = express()

const server = awsServerlessExpress.createServer(app)

//exports.handler = (event, context, callback) => {
exports.handler = (event, context) => {
  process.env.NODE_ENV == 'production';
  console.log(event)
  awsServerlessExpress.proxy(server, event, context)
}